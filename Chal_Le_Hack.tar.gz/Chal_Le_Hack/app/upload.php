<?php
if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de l’envoi du fichier.']);
    exit;
}

$filename = $_FILES['file']['name'];
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if (!in_array($ext, ['doc', 'docx', 'xls', 'xlsx', 'odt', 'ods'])) {
    echo json_encode(['success' => false, 'message' => 'Type de fichier non autorisé.']);
    exit;
}

$uploadedFile = 'uploads/' . $filename;
$convertedFile = 'converted/' . pathinfo($filename, PATHINFO_FILENAME) . '.pdf';

if (!move_uploaded_file($_FILES['file']['tmp_name'], $uploadedFile)) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de l’envoi du fichier.']);
    exit;
}

$file = escapeshellarg($uploadedFile);
$command = "libreoffice6.3 --headless --convert-to pdf --outdir converted/ $file";
shell_exec($command);

if (!file_exists($convertedFile)) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de la conversion en PDF.']);
    exit;
}

echo json_encode(['success' => true, 'path' => $convertedFile]);
