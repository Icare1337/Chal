<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Convertor</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>
        <pre>
<?php echo shell_exec('figlet Convertor'); ?>
        </pre>
        </h1>
        <p><strong>Upload an office file to convert it to PDF</strong></p>
        <form id="upload-form" enctype="multipart/form-data">
            <input type="file" name="file" accept=".doc,.docx,.xls,.xlsx,.odt,.ods">
            <input type="submit" value="Convert">
        </form>
        <div id="loader" class="spinner-border text-primary" style="display:none;" role="status"></div>
        <div id="error" class="alert alert-danger" style="display:none;"></div>
        <div id="pdf"></div>
    </div>
    <script>
        $('#upload-form').on('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);

            $.ajax({
                type: 'POST',
                url: 'upload.php',
                data: formData,
                cache: false,
                contentType: false,
                dataType: 'json',
                processData: false,
                beforeSend: function () {
                    $('#loader').show();
                    $('#error').hide();
                },
                success: function(response) {
                    if (response.success) {
                        $('#pdf').html('<embed src="' + response.path + '" width="100%" height="500px">');
                    } else {
                        $('#error').text(response.message).show();
                    }
                },
                complete: function () {
                    $('#loader').hide();
                },
                error: function() {
                    $('#error').text('Erreur lors de l’envoi du fichier.').show();
                }
            });
        });
    </script>
</body>
</html>
